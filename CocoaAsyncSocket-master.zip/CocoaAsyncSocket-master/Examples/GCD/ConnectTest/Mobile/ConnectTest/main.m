//
//  main.m
//  ConnectTest
//
//  Created by Robbie Hanson on 7/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
	@autoreleasepool {
		int retVal = UIApplicationMain(argc, argv, nil, nil);
		return retVal;
	}
}
